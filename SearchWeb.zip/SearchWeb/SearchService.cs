﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace SearchWeb
{
    public interface ISearchService
    {
        Task<SearchResult> SearchAsync(string searchTerm);
    }
    public class SearchService : ISearchService
    {

        private readonly HttpClient _httpClient = null!;
        private readonly ILogger<SearchService> _logger = null!;

        public SearchService(HttpClient httpClient, ILogger<SearchService> logger) =>
            (_httpClient, _logger) = (httpClient, logger);

        public async Task<SearchResult> SearchAsync(string searchTerm)
        {
            SearchResult result = null;

            var res = await _httpClient.GetAsync($"https://itunes.apple.com/search?term={searchTerm}");
            if(res.IsSuccessStatusCode)
            {
                result = JsonConvert.DeserializeObject<SearchResult>(await res.Content.ReadAsStringAsync());
            }

            return result;
        }
    }
}
