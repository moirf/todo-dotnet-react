﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchWeb
{
    [JsonObject]
    public class SearchResult
    {
        [JsonProperty(PropertyName = "resultCount", DefaultValueHandling = DefaultValueHandling.Ignore)]

        public int ResultCount { get; set; }

        readonly List<SearchItem> results = new List<SearchItem>();

        [JsonProperty(PropertyName = "results", DefaultValueHandling = DefaultValueHandling.Ignore)]
        public IList<SearchItem> Results { 
            get { return results; } 
        }

    }
    public class SearchItem
    {
        public string wrapperType { get; set; }
        public string kind { get; set; }
        public int collectionId { get; set; }
        public int trackId { get; set; }
        public string artistName { get; set; }
        public string collectionName { get; set; }
        public string trackName { get; set; }
        public string collectionCensoredName { get; set; }
        public string trackCensoredName { get; set; }
        public int collectionArtistId { get; set; }
        public string collectionArtistViewUrl { get; set; }
        public string collectionViewUrl { get; set; }
        public string trackViewUrl { get; set; }
        public string previewUrl { get; set; }
        public string artworkUrl30 { get; set; }
        public string artworkUrl60 { get; set; }
        public string artworkUrl100 { get; set; }
        public double collectionPrice { get; set; }
        public double trackPrice { get; set; }
        public double trackRentalPrice { get; set; }
        public double collectionHdPrice { get; set; }
        public double trackHdPrice { get; set; }
        public double trackHdRentalPrice { get; set; }
        public DateTime releaseDate { get; set; }
        public string collectionExplicitness { get; set; }
        public string trackExplicitness { get; set; }
        public int trackCount { get; set; }
        public int trackNumber { get; set; }
        public int trackTimeMillis { get; set; }
        public string country { get; set; }
        public string currency { get; set; }
        public string primaryGenreName { get; set; }
        public string contentAdvisoryRating { get; set; }
        public string longDescription { get; set; }
        public bool hasITunesExtras { get; set; }

    }
}
